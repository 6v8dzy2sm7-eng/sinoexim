# SINOEXIM Global Partners — sinoexim.by

Kurumsal web sitesi. 4 dil (RU/TR/EN/ZH), açık/koyu tema.

## Dosyalar
- `index.html` — Sitenin tamamı. Logolar ve fotoğraflar dosyanın içindedir; tek başına da açılır.
- `assets/img/og.jpg`, `assets/img/icon-512.png` — Sosyal medya paylaşım görseli ve Google için logo (sitenin görünümü için gerekli değil).
- `robots.txt`, `sitemap.xml` — Arama motorları için.
- `404.html` — Bulunamayan adresleri ana sayfaya yönlendirir.

## GitHub Pages ile yayınlama
1. Bu klasördeki her şeyi yeni bir depoya yükleyin.
2. Settings → Pages → Branch: `main`, klasör: `/ (root)` → Save.
3. sinoexim.by için Settings → Pages → Custom domain alanına `sinoexim.by` yazın ve alan adı sağlayıcınızda DNS kaydını GitHub Pages'e yönlendirin.
