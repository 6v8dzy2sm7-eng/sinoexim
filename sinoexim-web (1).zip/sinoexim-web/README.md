# SINOEXIM Global Partners — sinoexim.by

Tek dosyalık (index.html) kurumsal web sitesi. 4 dil (RU/TR/EN/ZH), açık/koyu tema.

## GitHub Pages ile yayınlama
1. Bu iki dosyayı yeni bir depoya yükleyin.
2. Settings → Pages → Branch: `main`, klasör: `/ (root)` → Save.
3. Birkaç dakika sonra site `https://<kullanıcı-adı>.github.io/<depo-adı>/` adresinde açılır.
4. Kendi alan adınız (sinoexim.by) için Settings → Pages → Custom domain alanına `sinoexim.by` yazın ve alan adı sağlayıcınızda DNS kaydını GitHub Pages'e yönlendirin.

Not: Fotoğraflar ve logolar dosyanın içine gömülüdür, ayrıca yüklemeniz gerekmez.
